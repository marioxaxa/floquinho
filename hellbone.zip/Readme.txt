------------------------------------------------------
You can download another font here
Graphic River
https://graphicriver.net/user/aphriellart/portfolio
Creative Fabrica
https://www.creativefabrica.com/designer/esaprasetio
------------------------------------------------------


------------------------------------------------------
For Demo Font Here

Pixelify
https://pixelify.net/artist/aphriellart/

Dafont
https://www.dafont.com/profile.php?user=979027

1001 Font
https://www.1001fonts.com/users/aphriellart/
------------------------------------------------------


***************************
You can donate me at paypal
esaprasetio@gmail.com
***************************

Thank you!